/**
 * A program Indulási osztálya
 */
public class Main {
    /**
     * A program belépési pontja
     * @param args Futtatási argumentumok
     */
    public static  void main(String[] args){
        new MenuFrame(); //Megnyit egy Menu Framet
    }
}
