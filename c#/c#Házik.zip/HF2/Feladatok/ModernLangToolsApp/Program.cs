﻿using System.ComponentModel;
using System.Threading.Channels;
using System.Xml.Serialization;

namespace ModernLangToolsApp;

public class Program
{
    [Description("Feladat2")]
    public static void SaveAndLoad()
    {
        var ser = new XmlSerializer(typeof(Jedi));
        var saveThis = new Jedi() { Name = "Skywalker", MidiChlorianCount = 25000 };
        var stream = new StreamWriter(File.Open("Jedi.xml", FileMode.Create));
        ser.Serialize(stream, saveThis);
        stream.Close();
        var stream2 = new StreamReader(File.Open("Jedi.xml", FileMode.Open));
        var loaded = ser.Deserialize(stream2) as Jedi;
        stream2.Close();
        Console.WriteLine("{0}\t{1}",loaded.Name, loaded.MidiChlorianCount);
    }

    [Description("Feladat3")]
    public static void LoggerTest()
    {
        var s = new JediStorage();
        s.JediLogger += msg => Console.WriteLine(msg);

        initialize(s);

        for (int i = 0; i < 12; i++)
            s.Remove();
    }

    [Description("Feladat4")]
    public static void FilterTest()
    {
        var s = new JediStorage();
        initialize(s);
        var news = s.Filter_Delegate();
        foreach (var item in news)
        {
            Console.WriteLine("{0}\t{1}", item.Name, item.MidiChlorianCount);
        }

    }

    [Description("Feladat5")]
    public static void LambdaFilterTest()
    {
        var s = new JediStorage();
        initialize(s);
        var news = s.Filter_Lambda();
        foreach (var item in news)
        {
            Console.WriteLine("{0}\t{1}", item.Name, item.MidiChlorianCount);
        }
    }

    [Description("Feladat6")]
    public static void TestCountIf()
    {
        var s = new JediStorage();
        initialize(s);
        Console.WriteLine("All jedi:\t\t\t" + s.count);
        Console.WriteLine("MidiChlorianCount % 200 == 0:\t" + s.CountIf(jedi => jedi.MidiChlorianCount % 200 == 0));
        
    }

    public static void initialize(JediStorage s)
    {
        for (int i = 0; i < 12; i++)
            s.Add(new Jedi { Name = $"Jedi{i}" , MidiChlorianCount = ((i+1)*100)});
    }

   

    public static void Main(string[] args)
    {
        Console.WriteLine("2. feladat\n");
        SaveAndLoad();
        Console.WriteLine("\n3. feladat\n");
        LoggerTest();
        Console.WriteLine("\n4. feladat\n");
        FilterTest();
        Console.WriteLine("\n5. feladat\n");
        LambdaFilterTest();
        Console.WriteLine("\n6. feladat\n");
        TestCountIf();
    }
}
