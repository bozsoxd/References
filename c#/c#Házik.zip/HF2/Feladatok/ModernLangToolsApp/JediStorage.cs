﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModernLangToolsApp
{
    public delegate void Logger(string message);
    public class JediStorage
    {
        private List<Jedi> jediList = new List<Jedi>();
        public int count => jediList.Count;
        public event Logger JediLogger;
        public void Add(Jedi jedi)
        {
            JediLogger?.Invoke($"New Jedi: {jedi.Name}");
            jediList.Add(jedi);
        }
        public void Remove() 
        {
            var last = jediList.Last();
            JediLogger?.Invoke($"Removed Jedi: {last.Name}");
            jediList.RemoveAt(jediList.Count - 1);
            if(jediList.Count == 0)
            {
                JediLogger?.Invoke($"The council is empty");
            }
        }

        private static bool filter(Jedi j)
        {
            return j.MidiChlorianCount < 530;
        }

        public List<Jedi> Filter_Delegate()
        {
            return jediList.FindAll(filter);
        }

        public List<Jedi> Filter_Lambda() => jediList.FindAll(jedi => jedi.MidiChlorianCount < 1000);

        public int CountIf(Func<Jedi, bool> predicate) => jediList.Count(jedi => predicate(jedi));

    }
}
