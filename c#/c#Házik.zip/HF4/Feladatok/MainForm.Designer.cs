﻿namespace MultiThreadedApp
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pTarget = new Panel();
            bBike1 = new Button();
            bStart = new Button();
            bBike2 = new Button();
            bBike3 = new Button();
            pStart = new Panel();
            bStep = new Button();
            pDepo = new Panel();
            bStep2 = new Button();
            bTav = new Button();
            SuspendLayout();
            // 
            // pTarget
            // 
            pTarget.BackColor = Color.LightSteelBlue;
            pTarget.Location = new Point(810, 51);
            pTarget.Name = "pTarget";
            pTarget.Size = new Size(183, 355);
            pTarget.TabIndex = 0;
            // 
            // bBike1
            // 
            bBike1.Font = new Font("Webdings", 31.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            bBike1.Location = new Point(44, 64);
            bBike1.Name = "bBike1";
            bBike1.Size = new Size(166, 90);
            bBike1.TabIndex = 1;
            bBike1.Text = "b";
            bBike1.UseVisualStyleBackColor = true;
            bBike1.Click += bBike1_Click;
            // 
            // bStart
            // 
            bStart.Location = new Point(44, 455);
            bStart.Name = "bStart";
            bStart.Size = new Size(166, 57);
            bStart.TabIndex = 2;
            bStart.Text = "Start";
            bStart.UseVisualStyleBackColor = true;
            bStart.Click += bStart_Click;
            // 
            // bBike2
            // 
            bBike2.Font = new Font("Webdings", 31.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            bBike2.Location = new Point(44, 180);
            bBike2.Name = "bBike2";
            bBike2.Size = new Size(166, 92);
            bBike2.TabIndex = 3;
            bBike2.Text = "b";
            bBike2.UseVisualStyleBackColor = true;
            bBike2.Click += bBike1_Click;
            // 
            // bBike3
            // 
            bBike3.Font = new Font("Webdings", 31.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            bBike3.Location = new Point(44, 298);
            bBike3.Name = "bBike3";
            bBike3.Size = new Size(166, 94);
            bBike3.TabIndex = 4;
            bBike3.Text = "b";
            bBike3.UseVisualStyleBackColor = true;
            bBike3.Click += bBike1_Click;
            // 
            // pStart
            // 
            pStart.BackColor = Color.SlateGray;
            pStart.Location = new Point(246, 51);
            pStart.Name = "pStart";
            pStart.Size = new Size(190, 355);
            pStart.TabIndex = 5;
            // 
            // bStep
            // 
            bStep.Location = new Point(246, 455);
            bStep.Name = "bStep";
            bStep.Size = new Size(190, 57);
            bStep.TabIndex = 6;
            bStep.Text = "Step1";
            bStep.UseVisualStyleBackColor = true;
            bStep.Click += bStep_Click;
            // 
            // pDepo
            // 
            pDepo.BackColor = Color.LightSkyBlue;
            pDepo.Location = new Point(534, 51);
            pDepo.Name = "pDepo";
            pDepo.Size = new Size(173, 355);
            pDepo.TabIndex = 7;
            // 
            // bStep2
            // 
            bStep2.Location = new Point(534, 455);
            bStep2.Name = "bStep2";
            bStep2.Size = new Size(173, 57);
            bStep2.TabIndex = 8;
            bStep2.Text = "Step2";
            bStep2.UseVisualStyleBackColor = true;
            bStep2.Click += bStep2_Click;
            // 
            // bTav
            // 
            bTav.Location = new Point(810, 455);
            bTav.Name = "bTav";
            bTav.Size = new Size(183, 57);
            bTav.TabIndex = 9;
            bTav.Text = "Tav";
            bTav.UseVisualStyleBackColor = true;
            bTav.Click += bTav_Click;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1016, 548);
            Controls.Add(bTav);
            Controls.Add(bStep2);
            Controls.Add(bStep);
            Controls.Add(bBike3);
            Controls.Add(bBike2);
            Controls.Add(bStart);
            Controls.Add(bBike1);
            Controls.Add(pTarget);
            Controls.Add(pStart);
            Controls.Add(pDepo);
            Name = "MainForm";
            Text = "Tour de France - RIPKBY";
            ResumeLayout(false);
        }

        #endregion

        private Panel pTarget;
        private Button bBike1;
        private Button bStart;
        private Button bBike2;
        private Button bBike3;
        private Panel pStart;
        private Button bStep;
        private Panel pDepo;
        private Button bStep2;
        private Button bTav;
    }
}