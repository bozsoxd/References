namespace MultiThreadedApp
{
    public partial class MainForm : Form
    {
        private static long speedometer;
        public Panel end;
        private Bike b1;
        private Bike b2;
        private Bike b3;
        public static ManualResetEvent mre = new ManualResetEvent(false);
        public static AutoResetEvent are = new AutoResetEvent(false);
        private static object sync = new object();
        private int startLeft;
        public MainForm()
        {
            InitializeComponent();
            end = pTarget;
            b1 = new Bike(bBike1, this) { megallok = new[] { pStart, pDepo, pTarget } };
            b2 = new Bike(bBike2, this) { megallok = new[] { pStart, pDepo, pTarget } };
            b3 = new Bike(bBike3, this) { megallok = new[] { pStart, pDepo, pTarget } };
            startLeft = bBike1.Left;
        }



        private void bStart_Click(object sender, EventArgs e)
        {
            b1.StartBike(bBike1);
            b2.StartBike(bBike2);
            b3.StartBike(bBike3);
        }


        private void bStep_Click(object sender, EventArgs e)
        {
            mre.Set();

        }

        private void bStep2_Click(object sender, EventArgs e)
        {
            are.Set();

        }

        private void bTav_Click(object sender, EventArgs e)
        {
            bTav.Text = GetPixels().ToString();
        }

        public static void IncreasePixels(long step)
        {
            lock (sync)
            {
                speedometer += step;
            }
        }

        public static long GetPixels()
        {
            lock (sync)
            {
                return speedometer;
            }
        }

        private void bBike1_Click(object sender, EventArgs e)
        {
            
            Button bike = (Button)sender;
            Bike b = (Bike)bike.Tag;
            Thread t = b.GetThread();
            if (t == null) { return; }
            t.Interrupt();
            t.Join();
            bike.Left = startLeft;
            b.reset();
            b.StartBike(bike);
        }
    }
}