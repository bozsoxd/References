﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiThreadedApp
{
    internal class Bike
    {
        private bool elindult = false;
        private bool startontul = false;
        private bool depontul = false;
        private readonly Button BikeButton;
        private readonly Random random = new Random();
        private Form main;
        public Panel[] megallok;
        private Thread t;
        
        public Thread GetThread() { return t; }
        
       
        public Bike(Button BikeBu, MainForm main)
        {
            this.BikeButton = BikeBu;
            this.main = main;
            
        }

        
        

        private bool elerte(Panel p)
        {
            return BikeButton.Left >= p.Left;
        }

        public void BikeThreadFunction(object param)
        {
            try
            {
                var bike = (Button)param;
                while (!elerte(megallok[2]))
                {

                    if (elerte(megallok[0]) && !startontul)
                    {
                        startontul = true;
                        MainForm.mre.WaitOne();
                    }
                    if (elerte(megallok[1]) && !depontul)
                    {
                        depontul = true;
                        MainForm.are.WaitOne();
                    }
                    MoveBike(bike);
                    Thread.Sleep(100);
                }
            }
            catch (ThreadInterruptedException) 
            {
                
            }
            
        }
        
        public void reset()
        {
            elindult = false;
            startontul = false;
            depontul = false;
            MainForm.mre.Reset();
        }

        public void MoveBike(Button bike)
        {
            if (main.InvokeRequired)
            {
                main.Invoke(MoveBike, bike);
            }
            else
            {
                int step = random.Next(2, 8);
                bike.Left += step;
                MainForm.IncreasePixels(step);
            }
        }


        public void StartBike(Button bBike)
        {
            if (!elindult)
            {
                t = new Thread(BikeThreadFunction)
                {
                    IsBackground = true, // Ne blokkolja a szál a processz megszűnését
                };

                bBike.Tag = this;
                t.Start(bBike);
                elindult = true;
            }
            
        }




    }
}
