﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Signals
{
    public class SignalValue
    {
        public readonly double Value;
        public readonly System.DateTime TimeStamp;

        public SignalValue(double Value, System.DateTime TimeStamp)
        {
            this.Value = Value;
            this.TimeStamp = TimeStamp;
        }
        public override string ToString()
        {
            return $"Value: {Value}, TimeStamp: {TimeStamp}";
        }

    }
}
