﻿using Signals.DocView;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Signals
{
    public partial class GraphicsSignalView : UserControl, IView
    {
        public int ViewNumber { get; set; }
        private Document document; 
        public GraphicsSignalView(SignalDocument document) : this() //Konstruktor SignalDocumentr
        {

            this.document = document;
        }

        public GraphicsSignalView() //default konstruktor, amely inicializálja a komponenseket
        {
            InitializeComponent();
        }

        public Document GetDocument() //vissza adja a Documentet
        {
            return document;
        }

        protected override void OnPaint(PaintEventArgs e) //Rajzoló függvény
        {
            base.OnPaint(e); //Ős OnPaint-je
            var pen = new Pen(Color.Blue, 2) //Kék pen
            {
                DashStyle = DashStyle.Dot, //Pontozott
                EndCap = LineCap.ArrowAnchor, //Nyil a végén
            };
            e.Graphics.DrawLine(pen, 2, ClientSize.Height, 2, 0); //y tengely
            e.Graphics.DrawLine(pen, 0, ClientSize.Height / 2, ClientSize.Width, ClientSize.Height / 2); //x tengely a képernyő fele magasságában
            var brush = new SolidBrush(Color.Blue); //Kék ecset
            DateTime elozo = DateTime.Now; //Az előző Signal ideje
            bool first = true; //Első pont
            int prevx = 0; //Előző x,y
            var prevy = 0;
            var actualx = 0; //Aktuális x,y
            var actualy = 0;
            var pixelPerHours = 0.1; //Pixel óránként
            var pixelPerValues = 5; //Pixel szorzója a valuenak
            foreach (var signal in ((SignalDocument)document).Signals) //Végig megy a signals listán
            {
                if (!first) //Első esetben az x marad 0
                {
                    actualx = (int)((prevx + (int)(signal.TimeStamp - elozo).TotalHours * pixelPerHours)*zoom); //Az előző és a mostani közt eltelt idő órában és szorozva az óránkénti pixelszámmal és szorozva a zoommal
                }
                actualy = ClientSize.Height / 2 + (int)((signal.Value)*pixelPerValues*zoom); //Aktuális y a magassaág felétől számítva, szorozva a zoommal

                e.Graphics.FillRectangle(brush, new Rectangle(actualx, actualy, 3, 3)); // pontok kirajzolása
                if(actualx != 0)
                {
                    e.Graphics.DrawLine(Pens.Blue, prevx, prevy, actualx, actualy); //Vonalak kirajzolása
                }
                prevy = actualy;
                prevx = actualx;
                elozo = signal.TimeStamp;
                first = false;
            }

        }
        private double zoom = 1;

        private void button2_Click(object sender, EventArgs e) //Kicsinyítés
        {
            zoom /= 1.2;
            Invalidate();
        }

        private void bPlus_Click(object sender, EventArgs e) //Nagyítás
        {
            zoom *= 1.2;
            Invalidate();
        }
    }
}
