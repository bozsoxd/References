﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;

namespace Signals
{
    public class SignalDocument : DocView.Document
    {
        private List<SignalValue> signals = new List<SignalValue>();

        private SignalValue[] testValues = new SignalValue[]
        {
        new SignalValue(15, new DateTime(2023, 2, 3, 1, 10, 0, 111)),
        new SignalValue(25, new DateTime(2023, 4, 5, 2, 20, 1, 876)),
        new SignalValue(35, new DateTime(2023, 6, 7, 3, 11, 2, 300)),
        new SignalValue(15, new DateTime(2023, 8, 9, 4, 21, 3, 232)),
        new SignalValue(-15, new DateTime(2023, 10, 11, 12, 4, 44, 885)),
        new SignalValue(-24, new DateTime(2023, 12, 13, 22, 5, 33, 125)),
        };
        public SignalDocument(string name): base(name)
        {
            signals.AddRange(testValues);
        }

        public override void SaveDocument(string filePath)
        {
            base.SaveDocument(filePath);
            using (StreamWriter sw = new StreamWriter(filePath))
            {
                foreach (var signal in signals)
                {
                    var v = signal.Value;
                    var ts = signal.TimeStamp.ToUniversalTime().ToString("o");
                    sw.WriteLine(v +"\t" + ts);
                }

            }
            
        }

        public override void LoadDocument(string filePath)
        {
            signals.Clear();
            base.LoadDocument(filePath);
            string line;
            using (StreamReader sr = new StreamReader(filePath))
            {
                while ((line = sr.ReadLine()) != null)
                {
                    line = line.Trim();
                    string[] columns = line.Split("\t");
                    double d = double.Parse(columns[0]);
                    DateTime UTCdt = DateTime.Parse(columns[1]);
                    DateTime dt = UTCdt.ToLocalTime();
                    signals.Add(new SignalValue(d, dt));
                }
            }


                UpdateAllViews();
            TraceValues();
        }
        public IReadOnlyList<SignalValue> Signals
        {
            get { return signals; }
        }
        private void TraceValues()
        {
            foreach (var signal in signals)
                Trace.WriteLine(signal.ToString());
        }
    }

   




}