﻿namespace Signals
{
    partial class GraphicsSignalView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            bPlus = new Button();
            bMinus = new Button();
            SuspendLayout();
            // 
            // bPlus
            // 
            bPlus.Location = new Point(19, 30);
            bPlus.Name = "bPlus";
            bPlus.Size = new Size(38, 29);
            bPlus.TabIndex = 0;
            bPlus.Text = "+";
            bPlus.UseVisualStyleBackColor = true;
            bPlus.Click += bPlus_Click;
            // 
            // bMinus
            // 
            bMinus.Location = new Point(84, 30);
            bMinus.Name = "bMinus";
            bMinus.Size = new Size(35, 29);
            bMinus.TabIndex = 1;
            bMinus.Text = "-";
            bMinus.UseVisualStyleBackColor = true;
            bMinus.Click += button2_Click;
            // 
            // GraphicsSignalView
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(bMinus);
            Controls.Add(bPlus);
            Name = "GraphicsSignalView";
            Size = new Size(565, 376);
            ResumeLayout(false);
        }

        #endregion

        private Button bPlus;
        private Button bMinus;
    }
}
