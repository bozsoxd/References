# Szoftvertechnikák 1. házi feladat
