﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shapes
{
    public class Manager
    {
        private readonly List<Everything> list = new List<Everything>();
        public void add(Everything item) { list.Add(item); }
        public void remove(Everything item) { list.Remove(item);}
        public void clear() { list.Clear(); }
        
        public Everything get(int i) { return list.ElementAt(i); }
    
        public void outAll()
        {
            foreach(Everything i in list)
            {
                Console.WriteLine(i.ToString());
            }
        }
    }
}
