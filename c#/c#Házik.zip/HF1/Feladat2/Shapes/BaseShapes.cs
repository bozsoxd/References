﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shapes
{
    public abstract class BaseShapes : Everything
    {
        protected int x, y;
        public BaseShapes(int x, int y)
        { 
            this.x = x;
            this.y = y;
        }

        public abstract double getArea();

        public virtual string getTypeOfShape()
        {
            return "BaseShape";
        }

        public int GetX()
        {
            return x;
        }

        public int GetY()
        {
            return y;
        }
        public override string ToString()
        {
            return $"{getTypeOfShape()}  [{GetX()},{GetY()}] area={getArea()}";
        }
    }
}
