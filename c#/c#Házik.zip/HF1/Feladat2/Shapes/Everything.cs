﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shapes
{
    public interface Everything
    {
        int GetX();
        int GetY();
        double getArea();
        string getTypeOfShape();
    }
}
