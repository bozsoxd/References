﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shapes
{
    public class Square : Rectangle
    {
        public Square(int x, int y, int sideLength) : base(x, y, sideLength, sideLength)
        {
        }

        public override string getTypeOfShape()
        {
            return "Square";
        }
    }
}
