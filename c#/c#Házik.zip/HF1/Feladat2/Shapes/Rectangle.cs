﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shapes
{
    public class Rectangle : BaseShapes
    {
        protected int width, height;
        public Rectangle(int x, int y, int width, int height) : base(x, y)
        {
            this.width = width;
            this.height = height;
        }

        public int getHeight() { return height; }
        public int getWidth() { return width; }
        public override double getArea()
        {
            return height*width;
        }

        public override string getTypeOfShape()
        {
            return "Rectangle";
        }

        public override string ToString()
        {
            return base.ToString() + $" height={height} width={width}";
        }
    }
}
