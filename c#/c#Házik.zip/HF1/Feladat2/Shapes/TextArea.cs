﻿using Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shapes
{
    public class TextArea : Textbox, Everything
    {
        public TextArea(int x, int y, int w, int h) : base(x, y, w, h)
        {
        }

        public double getArea()
        {
            return GetHeight()*GetWidth();
        }

        public string getTypeOfShape()
        {
            return "TextArea";
        }

        

        public override string ToString()
        {
            return $"{getTypeOfShape()}  [{GetX()},{GetY()}] area={getArea()} height={GetHeight()} width={GetWidth()} text='{GetText()}'";
        }
    }
}
