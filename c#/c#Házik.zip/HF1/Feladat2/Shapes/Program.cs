﻿namespace Shapes;

public class Program
{
    public static void Main(string[] args)
    {
        var c1 = new Circle(10, 4, 7);
        var c2 = new Circle(98, 67, 2);
        var s1 = new Square(76, -34, 29);
        var s2 = new Square(12, 12, 12);
        var t1 = new TextArea(0, 0, 20, 30);
        var t2 = new TextArea(100, 200, 300, 400);
        
        Manager manager = new Manager();

        manager.add(c1);
        manager.add(c2);
        manager.add(s1);
        manager.add(s2);
        manager.add(t1);
        manager.add(t2);
        Console.WriteLine("Print all:");
        manager.outAll();

        Console.WriteLine("\nRemove first\n\nPrint all:");
        manager.remove(c1);
        manager.outAll();

        Console.ReadKey();
        
    }
}
