﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shapes
{
    public class Circle : BaseShapes
    {
        protected int radius;
        public Circle(int x, int y, int radius) : base(x, y)
        {
            this.radius = radius;
        }

        public int getRadius() { return radius; }

        public override double getArea()
        {
            return radius*radius*Math.PI;
        }

        

        public override string getTypeOfShape()
        {
            return "Circle";
        }

        public override string ToString()
        {
            return base.ToString() + $" radius={radius}";
        }
    }
}
