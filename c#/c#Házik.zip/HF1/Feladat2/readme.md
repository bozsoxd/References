# 2. Feladat megoldásának bemutatása

Az Everything interface feladata, hogy a többszörös osztály öröklés hiányának kikerüléseként ezt az interfacet tudja örökölni a TextArea is, így ez legősibb dolog.
Ezt örökli a BaseShapes, ami az ősosztálya minden alapvető alakzatnak. Ebben megvalósítjuk a metódusok alapjait és ezt öröklik a formák.
A Rectangle osztály célja a bővíthetőség, ha négyzetek mellett később másmilyen téglalap alapú formát szeretnénk tárolni.
A TextArea örökli a saját ősosztályát, amiből származtatni kellett valamint az Everything interfacet.
A Manager tárol egy Everythingből álló listát, képes ehhez elemeket adni és törölni ebből, valamint kilistázni az összes elemét, vagy megadni valahányadikat.