﻿namespace MusicApp;

public class Program
{
    public static void Main(string[] args)
    {
        List<Song> list = new List<Song>();
        StreamReader sr = null;
        try
        {

            sr = new StreamReader("music.txt");

            while (!sr.EndOfStream)
            {
                string olvas = sr.ReadLine();
                if (string.IsNullOrWhiteSpace(olvas))
                {
                    continue;
                }
                string[] sor = olvas.Split(';');
                for (int i = 1; i < sor.Length; i++)
                {
                    Song s = new Song(sor[0].Trim(), sor[i].Trim());
                    list.Add(s);
                }

            }
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
        finally
        {
            if( sr != null ) sr.Close();
        }

        foreach (Song s in list)
        {
            Console.WriteLine(s.ToString());
        }
        Console.ReadKey();
    }
}
