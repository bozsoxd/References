using System.ComponentModel.Design.Serialization;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Security.Policy;

namespace WinFormExpl
{
    public partial class MainForm : Form
    {
        private FileInfo loadedFile = null;
        float counter;
        readonly float counterInitialValue;
        public MainForm()
        {
            InitializeComponent();
            counterInitialValue = 60.0f;
        }

        private void miExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void miOpen_Click(object sender, EventArgs e)
        {
            var dlg = new InputDialog();
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                string result = dlg.Path;
                DirectoryInfo dir = new DirectoryInfo(result);
                if (dir == null) return;
                listView1.Items.Clear();
                try
                {
                    foreach (FileInfo fi in dir.GetFiles())
                    {
                        listView1.Items.Add(
                            new ListViewItem(new string[]
                            {
                                fi.Name,
                                fi.Length.ToString(),
                                fi.FullName
                            }));
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count != 1)
                return;
            var fullName = listView1.SelectedItems[0].SubItems[2].Text;
            FileInfo fi = new FileInfo(fullName);
            lName.Text = "Name: " + fi.Name;
            lCreated.Text = "Created: " + fi.CreationTime.ToString();
        }

        private void listView1_DoubleClick(object sender, EventArgs e)
        {
            var fullName = listView1.SelectedItems[0].SubItems[2].Text;
            string data = File.ReadAllText(fullName);
            tContent.Text = data;
            reloadTimer.Start();
            counter = counterInitialValue;
            loadedFile = new FileInfo(fullName);
        }

        private void reloadTimer_Tick(object sender, EventArgs e)
        {
            counter--;


            detailsPanel.Invalidate();

            if (counter <= 0)
            {
                counter = counterInitialValue;
                tContent.Text = File.ReadAllText(loadedFile.FullName);
            }
        }

        private void detailsPanel_Paint(object sender, PaintEventArgs e)
        {
            if (loadedFile != null)
            {
                float temp = 125.0f * (counter / 60.0f);
                Rectangle rect = new Rectangle(0, 0, (int)temp, 5);
                e.Graphics.FillRectangle(Brushes.Brown, rect);
            }
        }
    }
}